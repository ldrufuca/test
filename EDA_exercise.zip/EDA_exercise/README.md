# Exploratory Data Analysis on RNAseq data

## GSE210534

### https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE210534  

This project is structured as follows

- data folder contains a csv file with raw RNAseq counts and a metadata.csv file with basic sample information
- script folder should contain your code
- figures folder will contain your outputs

You are tasked with the following

1. load and organize data and metadata
2. evaluate per gene dispersion and average expression
3. filter poorly characterized genes
4. perform quantile normalization (either look for a function or implement one on your own) [ref:https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=&cad=rja&uact=8&ved=2ahUKEwiNopPMj8z9AhWJQ_EDHYMeBcMQFnoECAsQAQ&url=https%3A%2F%2Fen.wikipedia.org%2Fwiki%2FQuantile_normalization&usg=AOvVaw1u2Z9Ip111hE6x7q8foiDh][ref:https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=&cad=rja&uact=8&ved=2ahUKEwiNopPMj8z9AhWJQ_EDHYMeBcMQFnoECA0QAQ&url=https%3A%2F%2Fwww.nature.com%2Farticles%2Fs41598-020-72664-6&usg=AOvVaw0joym7nrfrPyOuNBApETFx]
5. perform Principal Component Analysis and draw conclusions on your samples (hint: look at scikit-learn package) [ref: https://www.youtube.com/watch?v=FgakZw6K1QQ]
6. perform Clustering Analysis and draw conclusions on your samples [ref:https://www.youtube.com/watch?v=7xHsRkOdVwo]
7. perform per-gene ANOVA test and post-hoc Tukey test on selected groups with pvalue correction for multiple testing
8. draw volcano plot highlighting differentially expressed genes in selected comparison
